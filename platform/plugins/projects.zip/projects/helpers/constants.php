<?php

if (!defined('PROJECTS_MODULE_SCREEN_NAME')) {
    define('PROJECTS_MODULE_SCREEN_NAME', 'projects');
}
