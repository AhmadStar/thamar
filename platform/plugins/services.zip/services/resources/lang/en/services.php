<?php

return [
    'name' => 'Services',
    'create' => 'New services',
];
