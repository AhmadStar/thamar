<?php

if (!defined('SERVICES_MODULE_SCREEN_NAME')) {
    define('SERVICES_MODULE_SCREEN_NAME', 'services');
}
