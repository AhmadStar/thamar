<div class="px-3">
    <p
        class="smiley"
        aria-hidden="true"
    ></p>
    <p>{{ $message ?? trans('core/base::tables.no_data') }}</p>
</div>
