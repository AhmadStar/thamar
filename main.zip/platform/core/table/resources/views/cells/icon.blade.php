<x-core::icon name="{{ $icon }}" class="{{ $positionClass }}" />
