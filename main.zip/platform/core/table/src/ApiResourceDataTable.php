<?php

namespace Botble\Table;

use Yajra\DataTables\ApiResourceDataTable as BaseApiResourceDataTable;

class ApiResourceDataTable extends BaseApiResourceDataTable
{
}
