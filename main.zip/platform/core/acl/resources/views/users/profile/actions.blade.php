<x-core::card.footer class="bg-transparent mt-3 p-0 pt-3">
    <div class="btn-list justify-content-end">
        <x-core::button
            type="submit"
            color="primary"
            icon="ti ti-circle-check"
        >
            {{ trans('core/acl::users.update') }}
        </x-core::button>
    </div>
</x-core::card.footer>
