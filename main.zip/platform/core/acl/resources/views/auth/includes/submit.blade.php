<x-core::button type="submit" color="primary" class="w-full" :icon="$icon">
    {{ $label }}
</x-core::button>
