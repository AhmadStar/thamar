<?php

namespace Database\Seeders;

use Botble\Ecommerce\Database\Seeders\OrderSeeder;

class OrderEcommerceSeeder extends OrderSeeder
{
}
