<?php

namespace Database\Seeders;

use Botble\Ecommerce\Database\Seeders\ProductLabelSeeder as BaseProductLabelSeeder;

class ProductLabelSeeder extends BaseProductLabelSeeder
{
}
